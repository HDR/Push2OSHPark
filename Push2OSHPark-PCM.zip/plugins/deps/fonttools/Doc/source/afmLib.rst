######
afmLib
######

.. automodule:: fontTools.afmLib
   :members:
   :undoc-members:
