######
varLib
######

.. toctree::
   :maxdepth: 2

   designspace
   interpolatable
   interpolate_layout
   merger
   models
   mutator

.. automodule:: fontTools.varLib
   :members:
   :undoc-members:
