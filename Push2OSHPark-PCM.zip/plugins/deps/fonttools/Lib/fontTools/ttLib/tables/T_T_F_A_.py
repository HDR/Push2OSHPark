from __future__ import print_function, division, absolute_import
from fontTools.misc.py23 import *
from . import asciiTable

class table_T_T_F_A_(asciiTable.asciiTable):
	pass
