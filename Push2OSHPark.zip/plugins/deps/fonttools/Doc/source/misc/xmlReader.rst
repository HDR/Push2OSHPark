#########
xmlReader
#########

.. automodule:: fontTools.misc.xmlReader
   :members:
   :undoc-members:
