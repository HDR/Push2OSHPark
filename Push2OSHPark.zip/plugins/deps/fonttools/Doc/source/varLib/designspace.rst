###########
designspace
###########

.. automodule:: fontTools.varLib.designspace
   :members:
   :undoc-members:
