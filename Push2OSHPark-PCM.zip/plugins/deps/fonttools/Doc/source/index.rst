fontTools Docs
==============

.. toctree::
   :maxdepth: 1

   afmLib
   agl
   cffLib
   designspaceLib/index
   encodings
   feaLib
   merge
   misc/index
   pens/index
   subset
   t1Lib
   ttLib/index
   ttx
   varLib/index
   voltLib

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
