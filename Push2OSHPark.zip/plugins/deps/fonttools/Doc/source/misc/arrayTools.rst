##########
arrayTools
##########

.. automodule:: fontTools.misc.arrayTools
   :members:
   :undoc-members:
