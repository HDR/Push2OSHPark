#####
merge
#####

.. automodule:: fontTools.merge
   :members:
   :undoc-members:
