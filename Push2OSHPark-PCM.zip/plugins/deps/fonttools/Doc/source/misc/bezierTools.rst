###########
bezierTools
###########

.. automodule:: fontTools.misc.bezierTools
   :members:
   :undoc-members:
