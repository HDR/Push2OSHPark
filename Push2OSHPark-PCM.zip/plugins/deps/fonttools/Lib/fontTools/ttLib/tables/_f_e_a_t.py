from __future__ import print_function, division, absolute_import
from fontTools.misc.py23 import *
from .otBase import BaseTTXConverter


class table__f_e_a_t(BaseTTXConverter):
	pass
