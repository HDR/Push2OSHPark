#########
textTools
#########

.. automodule:: fontTools.misc.textTools
   :members:
   :undoc-members:
