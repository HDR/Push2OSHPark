.. highlight:: python

=======
glifLib
=======

.. automodule:: ufoLib.glifLib
   :inherited-members:
   :members:
