#####
eexec
#####

.. automodule:: fontTools.misc.eexec
   :members:
   :undoc-members:
